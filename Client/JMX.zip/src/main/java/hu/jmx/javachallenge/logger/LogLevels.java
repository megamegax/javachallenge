package hu.jmx.javachallenge.logger;

/**
 * Created by megam on 2015. 11. 18..
 */
public enum LogLevels {
    MAP,DEBUG,INFO,
}
