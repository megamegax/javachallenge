@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.loxon.eu/CentralControl/")
package eu.loxon.centralcontrol;
